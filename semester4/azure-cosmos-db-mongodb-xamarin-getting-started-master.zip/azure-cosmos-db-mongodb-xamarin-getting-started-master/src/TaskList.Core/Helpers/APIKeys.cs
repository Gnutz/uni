﻿using System;
namespace TaskList.Core
{
    public static class APIKeys
    {
#error Enter the connection string you find in the Portal first
        public static readonly string ConnectionString = "";
    }
}
