# Azure Cosmos DB - MongoDB API with Xamarin Quick Start Changelog

<a name="1.0.0"></a>

# 1.0.0 - The App Releases

*Features*
* Initial release!
* Every feature below applies to both iOS and Android
* Page that lists of _all_ todo items, whether they are complete or not.
* Swipe left on an existing todo item in a list to delete it.
* Page that adds new todo items.
* Page that edits existing todo items.

*Bug Fixes*
* Brand new - no bugs here yet!

*Breaking Changes*
* Brand new - nothing to break!
