﻿CREATE TABLE [Land] (
  [LandID] uint,
  [Landenavn] string,
  [Landekode] string,
  PRIMARY KEY ([LandID])
);