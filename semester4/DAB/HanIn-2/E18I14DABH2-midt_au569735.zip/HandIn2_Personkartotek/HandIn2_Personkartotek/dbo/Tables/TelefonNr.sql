﻿CREATE TABLE [TelefonNr] (
  [Nummer] string,
  [Ejer] PersoID,
  [type] string,
  [Telefonselskab] SelskabID,
  PRIMARY KEY ([Nummer])
);