﻿
--Syntax Error: Incorrect syntax near [PersonID?AdresseID].
--CREATE TABLE [Alternativ Adresse] (
--  [PersonID?AdresseID] <type>,
--  [type] <type>
--);



GO
